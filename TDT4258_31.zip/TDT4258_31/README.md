# Build and upload

To build and upload a solution, run `make` then `make upload` from their respective directories.